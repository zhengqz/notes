#!/usr/bin/env python
# coding: utf-8


import os
import re
import time

from urlparse import urlparse

import pdfkit
import requests
import random
from bs4 import BeautifulSoup

html_template = """
<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
</head>
<body>
{content}
</body>
</html>
"""

HEASERS = {
    "Cookie": "atsp=1520861061995_1520861063571; Hm_lvt_2efddd14a5f2b304677462d06fb4f964=1520776075,1520776955,1520778050,1520861064; Hm_lpvt_2efddd14a5f2b304677462d06fb4f964=1520861067",
    "Accept": "text/html,application/xhtml+xml,application/xml;q=0.9,image/webp,image/apng,*/*;q=0.8",
    "Accept-Encoding": "gzip, deflate, br",
    "Accept-Language": "zh-CN,zh;q=0.9",
    "Cache-Control": "max-age=0",
    "Connection": "keep-alive",
    "Referer": "https",
    "Upgrade-Insecure-Requests": "1",
    "User-Agent": "Mozilla/5.0 (Windows NT 6.1; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/63.0.3239.108 Safari/537.36"
}


class Crawler(object):
    name = None

    def __init__(self, name, start_url):
        self.name = name
        self.start_url = start_url
        self.domain = '{uri.scheme}://{uri.netloc}'.format(
            uri=urlparse(self.start_url))

    @staticmethod
    def request(url, **kwargs):
        time.sleep(random.random())
        kwargs["headers"] = HEASERS
        response = requests.get(url, **kwargs)
        return response

    def parse_menu(self, response):
        raise NotImplementedError

    def parse_body(self, response):
        raise NotImplementedError

    def run(self):
        start_time = time.time()
        options = {
            'page-size': 'Letter',
            'margin-top': '0.75in',
            'margin-right': '0.75in',
            'margin-bottom': '0.75in',
            'margin-left': '0.75in',
            'encoding': "UTF-8",
            'custom-header': [
                ('Accept-Encoding', 'gzip')
            ],
            'cookie': [
                ('cookie-name1', 'cookie-value1'),
                ('cookie-name2', 'cookie-value2'),
            ],
            'outline-depth': 10,
        }

        htmls = []
        response = self.request(self.start_url)
        for index, url in enumerate(self.parse_menu(response)):
            html = self.parse_body(self.request(url))
            f_name = os.path.join("html", ".".join([str(index), "html"]))
            with open(f_name, "wb") as fd:
                fd.write(html)
            htmls.append(f_name)


        pdfkit.from_file(htmls, self.name + ".pdf", options=options)
        map(os.remove, htmls)
        total_time = time.time() - start_time
        print("总共耗时: %f 秒" % total_time)


class LiaoXueFengPython3Crawler(Crawler):

    def parse_menu(self, response):
        print(response)
        soup = BeautifulSoup(response.content, 'html.parser')
        menu_tag = soup.find_all(class_="uk-nav uk-nav-side")[1]
        for a in menu_tag.find_all('a'):
            url = a.get("href")
            if not url.startswith("http"):
                url = "".join([self.domain, url])
            yield url

    def parse_body(self, response):
        try:
            soup = BeautifulSoup(response.content, 'html.parser')
            body = soup.find_all(class_="x-wiki-content x-main-content")[0]
            title = soup.find('h4').get_text()
            center_tag = soup.new_tag("center")
            title_tag = soup.new_tag("h1")
            title_tag.string = title
            center_tag.insert(1, title_tag)
            body.insert(1, center_tag)
            html = str(body)
            pattern = "(<img .*?src=\")(.*?)(\")"

            def func(m):
                if not m.group(2).startswith("http"):
                    rtn = "".join(
                        [m.group(1), self.domain, m.group(2), m.group(3)])
                    return rtn
                else:
                    return "".join([m.group(1), m.group(2), m.group(3)])

            html = re.compile(pattern).sub(func, html)

            html = html_template.format(content=html)
            #html = html.encode("utf-8")
            return html
        except Exception as e:
            print("*"*100)
            print("error:", e)


if __name__ == "__main__":
    start_url = "https://www.liaoxuefeng.com/wiki/0014316089557264a6b348958f449949df42a6d3a2e542c000"
    crawler = LiaoXueFengPython3Crawler("Python3", start_url)
    crawler.run()
